module.exports = {
  data: {
    name: 'howgay',
    description: 'Tells you how gay you or another user is!',
    integration_types: [0, 1],  // Adjust these based on your needs
    contexts: [0, 1, 2],
    options: [
      {
        name: 'user',
        type: 6, // 6 is the type for USER
        description: 'The user to check the gayness of',
        required: false
      }
    ]
  },

  async execute(interaction) {
    // Get the user from the interaction options or default to the command user
    const user = interaction.options.getUser('user') || interaction.user;
    const userName = user.username;
    const userId = user.id;

    // Determine the percentage based on user ID
    let randomNumber;
    if (userId === '930426110771097601') {
      randomNumber = 0; // Always 0% gay for this user ID
    } else if (userId === '573049402114048042') {
      randomNumber = 1000; // Always 1000% gay for this user ID
    } else {
      randomNumber = Math.floor(Math.random() * 101); // Random percentage between 0 and 100
    }
    
    const randomColor = Math.floor(Math.random() * 16777215); // Random hex color

    const embed = {
      color: randomColor,
      title: 'How Gay Are You?',
      description: `${userName} is ${randomNumber}% gay. 🏳️‍🌈`,
    };

    await interaction.reply({ embeds: [embed] });
  }
};
